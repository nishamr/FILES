// ============================================================================================================================
// 													 Get config file fields
// ============================================================================================================================

module.exports = function (cp, logger) {
	var helper = {};

	// get the  server port number
	helper.getPort = function () {
		return cp.getField('port');
	};

	// get the status of  previous startup
	helper.getEventsSetting = function () {
		if (cp.config['use_events']) {
			return cp.config['use_events'];
		}
		return false;
	};

	// get the re-enrollment period in seconds
	helper.getKeepAliveMs = function () {
		var sec = cp.getField('keep_alive_secs');
		if (!sec) sec = 30;									// default to 30 seconds
		return (sec * 1000);
	};

	return helper;
};
