#!/bin/bash

docker build -t LifeInsurance:local -f Dockerfile ../