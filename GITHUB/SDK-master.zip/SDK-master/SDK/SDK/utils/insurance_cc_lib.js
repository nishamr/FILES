module.exports = function (enrollObj, g_options, fcw, logger) {
    var insurance_chaincode = {};


    insurance_chaincode.create_insurance = function (options, cb) {
    console.log('');
    logger.info('Creating Insurance..');

    var opts = {
        peer_urls: g_options.peer_urls,
        peer_tls_opts: g_options.peer_tls_opts,
        channel_id: g_options.channel_id,
        chaincode_id: g_options.chaincode_id,
        chaincode_version: g_options.chaincode_version,
        event_urls: g_options.event_urls,
        endorsed_hook: options.endorsed_hook,
        ordered_hook: options.ordered_hook,
        cc_function: 'create',
        cc_args: [
            options.args.FirstName,
            options.args.LastName,
            options.args.PAN,
            options.args.DOB,
            options.args.AnnualIncome,
            options.args.PolicyNumber,
            options.args.CompanyName,
            options.args.InsuredAmount,
            options.args.Comments,
            options.args.NOP
        ],
    };
    fcw.invoke_chaincode(enrollObj, opts, cb);
};
};
