// SPDX-License-Identifier: Apache-2.0

'use strict';

var app = angular.module('application', []);

// Angular Controller
app.controller('appController', function($scope, appFactory){

	$("#success_holder").hide();
	$("#success_create").hide();
	$("#error_holder").hide();
	$("#error_query").hide();
	

	$scope.createInsurance = function(){

		appFactory.createInsurance($scope.insurance, function(data){
			$scope.create_Insurance = data;
			$("#success_create").show();
		});
	}

	$scope.queryInsurance = function(){
		var id = $scope.PAN;

		appFactory.queryInsurance(id, function(data){
			$scope.query_insurance = data;

			if ($scope.query_insurance == "Could not find insurance details for given PAN number"){
				console.log("Error in retrieving insurance details")
				$("#error_query").show();
			} else{
				$("#error_query").hide();
			}
		});
	}

	$scope.queryAllInsurance = function(){

		appFactory.queryAllInsurance(function(data){
			var array = [];
			for (var i = 0; i < data.length; i++){
				parseInt(data[i].Key);
				data[i].Record.Key = parseInt(data[i].Key);
				array.push(data[i].Record);
			}
			array.sort(function(a, b) {
			    return parseFloat(a.Key) - parseFloat(b.Key);
			});
			$scope.all_insurance = array;
		});
	}

});

// Angular Factory
app.factory('appFactory', function($http){
	
	var factory = {};

	factory.createInsurance = function(data, callback){

		var insurance = data.PAN + "-" + data.FirstName + "-" + data.LastName + "-" + data.DOB + "-" + data.AnnualIncome + "-" + data.Policies + "-" + data.Companies + "-" + data.InsuredAmt + "-" + data.Comments + "-" + data.NOP;

    	$http.get('/create_Insurance/'+insurance).success(function(output){
			callback(output)

		});
	}

	factory.queryInsurance = function(id, callback){
    	$http.get('/get_insurance/'+id).success(function(output){
			callback(output)
		});
	}

	factory.queryAllInsurance = function(callback){

    	$http.get('/get_all_insurance/').success(function(output){
			callback(output)
		});
	}

	return factory;
});


