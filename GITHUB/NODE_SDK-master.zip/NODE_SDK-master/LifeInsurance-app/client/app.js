// SPDX-License-Identifier: Apache-2.0

'use strict';

var app = angular.module('application', []);

// Angular Controller
app.controller('appController', function($scope, appFactory){

	$("#success_holder").hide();
	$("#success_create").hide();
	$("#error_holder").hide();
	$("#error_query").hide();
	

	$scope.createInsurance = function(){

		appFactory.createInsurance($scope.insurance, function(data){
			$scope.create_Insurance = data;
			$("#success_create").show();
		});
	}

});

// Angular Factory
app.factory('appFactory', function($http){
	
	var factory = {};

	factory.createInsurance = function(data, callback){

		var insurance = data.PAN + "-" + data.FirstName + "-" + data.LastName + "-" + data.DOB + "-" + data.AnnualIncome + "-" + data.Policies + "-" + data.Companies + "-" + data.InsuredAmt + "-" + data.Comments + "-" + data.NOP;

    	$http.get('/create_Insurance/'+insurance).success(function(output){
			callback(output)

		});
	}

	return factory;
});


