//SPDX-License-Identifier: Apache-2.0

var insurance = require('./controller.js');

module.exports = function(app){

  app.get('/create_Insurance/:insurance', function(req, res){
    insurance.create_Insurance(req, res);
  });
}
