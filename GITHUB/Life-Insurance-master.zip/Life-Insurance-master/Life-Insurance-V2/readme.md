updated chaincode and added new field status
