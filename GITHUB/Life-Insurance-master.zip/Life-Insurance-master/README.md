# Life-Insurance

put the basic network in the project folder to run the network
