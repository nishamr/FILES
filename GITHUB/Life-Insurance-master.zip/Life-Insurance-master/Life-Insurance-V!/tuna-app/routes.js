//SPDX-License-Identifier: Apache-2.0

var insurance = require('./controller.js');

module.exports = function(app){

  app.get('/get_policy/:pan', function(req, res){
    console.log("inside function")
    insurance.get_policy(req, res);
  });
  app.get('/create_policy/:policy', function(req, res){
    insurance.add_insurance(req, res);
  });
};
