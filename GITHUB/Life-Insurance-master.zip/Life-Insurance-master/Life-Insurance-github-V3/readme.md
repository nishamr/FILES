salary variation check included

comments updated
