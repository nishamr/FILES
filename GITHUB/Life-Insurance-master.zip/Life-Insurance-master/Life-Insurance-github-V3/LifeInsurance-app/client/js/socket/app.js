var app = angular.module("myApp", []);
app.controller("insuranceABC", function($scope,$http,$window) {
    $scope.protectionFactor="3";
    $scope.companyName="ABC_INSURANCE";
    $scope.redirectTo=function(name){
        if(name==="ABC"){
            $window.location.href = "insurer_1_purchase.html";
        }else if(name === "XYZ"){
            $window.location.href = "insurer_2_purchase.html";
        }else{
            $window.location.href = "index.html";
        }
    }
    $scope.showProceed= true;
    $scope.showDetails=false;
    $scope.showSearch=false;
    $scope.showTransaction=false;
    $scope.createPage=true;
    $scope.user={};
    $scope.totalInsuredAmount=0;
    $scope.showWarning=false;
    $scope.loading=false;
    $scope.smallerAmount=0;
    $scope.smallerAmountDiv=false;
    $scope.searchResultPolicy={};
    $scope.policies=[];
    $scope.numberOfPolicies=[];
    $scope.claimStatus=true;
    $scope.proceed=function(){
        $scope.loading=true;
        $scope.finalStep=false;
        console.log($scope.companyName);
        if($scope.smallerAmount!=0){
            $scope.user.insuredAmount=$scope.smallerAmount;
        }
        console.log("status :"+$scope.claimStatus);
        var policy = $scope.user.firstName + "," + $scope.user.lastName + "," + $scope.user.pan  + "," + $scope.user.dob  + "," + $scope.user.annualIncome + "," +$scope.companyName + "," + $scope.user.insuredAmount +","+ $scope.claimStatus +"," + $scope.user.comments;
        console.log(policy);
        $http.get('/create_policy/'+policy).then(function(output){
            console.log(output);
            $scope.txid=output.data;
            $scope.showTransaction=true;
            $scope.showProceed=false;
            $scope.showSearch=false;
            $scope.showDetails=false;
            $scope.loading=false;
            $scope.finalStep=false;
		}).catch(function(err){
            console.log(err);
            $scope.showTransaction=true;
            $scope.showProceed=false;
            $scope.showSearch=false;
            $scope.showDetails=false;
            $scope.loading=false;
            $scope.finalStep=false;
        });
        
    }

    $scope.checkDetails=function(){
        $scope.loading=true;
        $scope.totalInsuredAmount=0;
        $http.get('/get_policy/'+$scope.user.pan).then(function(output){
            console.log(output);
            if (output.data===""||output.data==null){
                $scope.finalStep=true;
                $scope.simpleConfirm=true;
                $scope.rejected=false;
                $scope.user.smallerAmountDiv=false;
            }else{
                var total_insureamount=0;
                for(var i=0;i<parseInt(output.data.nop);++i){
                    if(output.data.claim_status[i]==="APPROVED"){
                        total_insureamount=total_insureamount + parseInt(output.data.insured_amount[i]);
                    }
                }
                $scope.totalInsuredAmount=total_insureamount;
                console.log($scope.totalInsuredAmount);
                console.log(parseInt(output.data.annual_income)*1.3);
                if((parseInt($scope.totalInsuredAmount) < parseInt($scope.protectionFactor)*parseInt($scope.user.annualIncome))&&(parseInt($scope.user.annualIncome)<=parseInt(output.data.annual_income)*1.3)){
                    console.log("entered if loop : "+$scope.totalInsuredAmount +" AI :"+parseInt($scope.protectionFactor)*parseInt($scope.user.annualIncome));
                    if((parseInt($scope.totalInsuredAmount) + parseInt($scope.user.insuredAmount) ) < parseInt($scope.protectionFactor) * parseInt($scope.user.annualIncome)){
                        $scope.finalStep=true;
                        $scope.simpleConfirm=true;
                        $scope.claimStatus=true;
                        console.log($scope.claimStatus);
                        $scope.user.comments="";
                        $scope.rejected=false;
                        $scope.smallerAmountDiv=false;
                    }else{
                        $scope.finalStep=true;
                        $scope.simpleConfirm=false;
                        $scope.smallerAmountDiv=true;
                        $scope.claimStatus=true;
                        $scope.user.comments="";
                        $scope.rejected=false;
                        $scope.smallerAmount=(3*parseInt($scope.user.annualIncome) - parseInt($scope.totalInsuredAmount)).toString();
                        console.log($scope.smallerAmount);
                    }
                }else{
                    $scope.finalStep=true;
                    $scope.rejected=true;
                    $scope.claimStatus=false;
                    $scope.simpleConfirm=false;
                    $scope.smallerAmount=0;
                    if(parseInt($scope.user.annualIncome)>(parseInt(output.data.annual_income)*1.3)){
                        $scope.user.comments="High variation in the annual income";
                        $scope.user.annualIncome=output.data.annual_income;
                        console.log(output.data.annual_income);
                    }else{
                        $scope.user.comments="Maximum coverage utilised";
                    }
                }
            }
            $scope.showTransaction=false;
            $scope.showProceed=false;
            $scope.showSearch=false;
            $scope.createPage=true;
            $scope.loading=false;
        }).catch(function(err){
            console.log(err);
            $scope.showTransaction=false;
            $scope.showWarning=true;
            $scope.showProceed=false;
            $scope.showSearch=false;
            $scope.showDetails=false;
            $scope.loading=false;
            $scope.warningMessage="error :"+err;
        });;

    }
    $scope.closeResults=function(){
        $scope.showTransaction=false;
        $scope.showProceed=true;
        $scope.showSearch=false;
        $scope.createPage=true;
    }

    $scope.search=function(){
        $scope.policies=[];
        $scope.numberOfPolicies=[];
        console.log();
        $scope.loading=true;
        $scope.finalStep=false;
        console.log($scope.searchPan);
        $http.get('/get_policy/'+$scope.searchPan).then(function(output){
            console.log(output);
            if (output.data===""||output.data==null){
                $scope.createPage=true;
                $scope.showWarning=true;
                $scope.showTransaction=false;
                $scope.showProceed=false;
                $scope.showSearch=false;
                $scope.showDetails=false;
                $scope.loading=false;
                $scope.warningMessage="No results found for PAN : " + $scope.searchPan;
            }else{
                $scope.searchResults=output.data;
                    for(var i=0;i<parseInt($scope.searchResults.nop);++i){
                        $scope.numberOfPolicies.push(i);
                    }
                    $scope.showWarning=false;
                    $scope.createPage=false;
                    $scope.showSearch=true;
                    $scope.showTransaction=false;
                    $scope.showProceed=false;
                    $scope.loading=false;
            console.log($scope.searchResults);
            }
		}).catch(function(err){
            console.log(err);
        });

       
    }

    $scope.closeWarning=function(){
        $scope.showTransaction=false;
        $scope.showProceed=true;
        $scope.showSearch=false;
        $scope.showWarning=false;
        $scope.createPage=true;

    }
    $scope.createInsurance=function(){
        $scope.showProceed= true;
        $scope.createPage=true;
        $scope.showDetails=false;
        $scope.showSearch=false;
        $scope.showTransaction=false;
        $scope.finalStep=false;
        $scope.loading=false;
        $scope.smallerAmountDiv=false;
        $scope.smallerAmount=0;
        $scope.user={};
    }
  });


  app.controller("insuranceXYZ", function($scope,$http,$window) {
    $scope.protectionFactor="5";
    $scope.companyName="XYZ_INSURANCE";
    $scope.redirectTo=function(name){
        if(name==="home"){
            $window.location.href = "index.html";
        }else if(name === "XYZ"){
            $window.location.href = "insurer_2_purchase.html";
        }
    }
    $scope.showProceed= true;
    $scope.showDetails=false;
    $scope.showSearch=false;
    $scope.showTransaction=false;
    $scope.createPage=true;
    $scope.user={};
    $scope.totalInsuredAmount=0;
    $scope.showWarning=false;
    $scope.loading=false;
    $scope.smallerAmount=0;
    $scope.smallerAmountDiv=false;
    $scope.searchResultPolicy={};
    $scope.policies=[];
    $scope.claimStatus=true;
    $scope.numberOfPolicies=[];
    $scope.proceed=function(){
        $scope.loading=true;
        $scope.finalStep=false;
        console.log($scope.companyName);
        if($scope.smallerAmount!=0){
            $scope.user.insuredAmount=$scope.smallerAmount;
        }
        var policy = $scope.user.firstName + "," + $scope.user.lastName + "," + $scope.user.pan  + "," + $scope.user.dob  + "," + $scope.user.annualIncome + "," +$scope.companyName + "," + $scope.user.insuredAmount +","+ $scope.claimStatus +"," + $scope.user.comments;
        $http.get('/create_policy/'+policy).then(function(output){
            console.log(output);
            $scope.txid=output.data;
            $scope.showTransaction=true;
            $scope.showProceed=false;
            $scope.showSearch=false;
            $scope.showDetails=false;
            $scope.loading=false;
            $scope.finalStep=false;
		}).catch(function(err){
            console.log(err);
            $scope.showTransaction=true;
            $scope.showProceed=false;
            $scope.showSearch=false;
            $scope.showDetails=false;
            $scope.loading=false;
            $scope.finalStep=false;
        });
        
    }

    $scope.checkDetails=function(){
        $scope.loading=true;
        $scope.totalInsuredAmount=0;
        $http.get('/get_policy/'+$scope.user.pan).then(function(output){
            console.log(output);
            if (output.data===""||output.data==null){
                $scope.finalStep=true;
                $scope.simpleConfirm=true;
                $scope.rejected=false;
                $scope.user.smallerAmountDiv=false;
            }else{
                var total_insureamount=0;
                for(var i=0;i<parseInt(output.data.nop);++i){
                    if(output.data.claim_status[i]==="APPROVED"){
                        total_insureamount=total_insureamount + parseInt(output.data.insured_amount[i]);
                    }
                }
                $scope.totalInsuredAmount=total_insureamount;
                console.log($scope.totalInsuredAmount);
                console.log(parseInt(output.data.annual_income)*1.3);
                if((parseInt($scope.totalInsuredAmount) < parseInt($scope.protectionFactor)*parseInt($scope.user.annualIncome))&&(parseInt($scope.user.annualIncome)<=parseInt(output.data.annual_income)*1.3)){
                    console.log("entered if loop : "+$scope.totalInsuredAmount +" AI :"+parseInt($scope.protectionFactor)*parseInt($scope.user.annualIncome));
                    if((parseInt($scope.totalInsuredAmount) + parseInt($scope.user.insuredAmount) ) < parseInt($scope.protectionFactor) * parseInt($scope.user.annualIncome)){
                        $scope.finalStep=true;
                        $scope.simpleConfirm=true;
                        $scope.claimStatus=true;
                        console.log($scope.claimStatus);
                        $scope.user.comments="";
                        $scope.rejected=false;
                        $scope.smallerAmountDiv=false;
                    }else{
                        $scope.finalStep=true;
                        $scope.simpleConfirm=false;
                        $scope.smallerAmountDiv=true;
                        $scope.claimStatus=true;
                        $scope.user.comments="";
                        $scope.smallerAmount=(parseInt($scope.protectionFactor)*parseInt($scope.user.annualIncome) - parseInt($scope.totalInsuredAmount)).toString();
                        console.log($scope.smallerAmount);
                    }
                }else{
                    $scope.finalStep=true;
                    $scope.rejected=true;
                    $scope.claimStatus=false;
                    $scope.simpleConfirm=false;
                    $scope.smallerAmount=0;
                    if(parseInt($scope.user.annualIncome)>(parseInt(output.data.annual_income)*1.3)){
                        $scope.user.comments="High variation in the annual income";
                        $scope.user.annualIncome=output.data.annual_income;
                        console.log(output.data.annual_income);
                    }else{
                        $scope.user.comments="Maximum coverage utilised";
                    }
                }
            }
            $scope.showTransaction=false;
            $scope.showProceed=false;
            $scope.showSearch=false;
            $scope.createPage=true;
            $scope.loading=false;
        }).catch(function(err){
            console.log(err);
            $scope.showTransaction=false;
            $scope.showWarning=true;
            $scope.showProceed=false;
            $scope.showSearch=false;
            $scope.showDetails=false;
            $scope.loading=false;
            $scope.warningMessage="error :"+err;

        });;

    }
    $scope.closeResults=function(){
        $scope.showTransaction=false;
        $scope.showProceed=true;
        $scope.showSearch=false;
        $scope.createPage=true;
    }

    $scope.search=function(){
        $scope.policies=[];
        $scope.numberOfPolicies=[];
        console.log();
        $scope.loading=true;
        $scope.finalStep=false;
        console.log($scope.searchPan);
        $http.get('/get_policy/'+$scope.searchPan).then(function(output){
            console.log(output);
            if (output.data===""||output.data==null){
                $scope.createPage=true;
                $scope.showWarning=true;
                $scope.showTransaction=false;
                $scope.showProceed=false;
                $scope.showSearch=false;
                $scope.showDetails=false;
                $scope.loading=false;
                $scope.warningMessage="No results found for PAN : " + $scope.searchPan;
            }else{
                $scope.searchResults=output.data;
                    for(var i=0;i<parseInt($scope.searchResults.nop);++i){
                        $scope.numberOfPolicies.push(i);
                    }
                    $scope.showWarning=false;
                    $scope.createPage=false;
                    $scope.showSearch=true;
                    $scope.showTransaction=false;
                    $scope.showProceed=false;
                    $scope.loading=false;
            console.log($scope.searchResults);
            }
		}).catch(function(err){
            console.log(err);
        });

       
    }

    $scope.closeWarning=function(){
        $scope.showTransaction=false;
        $scope.showProceed=true;
        $scope.showSearch=false;
        $scope.showWarning=false;
        $scope.createPage=true;

    }
    $scope.createInsurance=function(){
        $scope.showProceed= true;
        $scope.createPage=true;
        $scope.showDetails=false;
        $scope.showSearch=false;
        $scope.showTransaction=false;
        $scope.finalStep=false;
        $scope.loading=false;
        $scope.smallerAmountDiv=false;
        $scope.smallerAmount=0;
        $scope.user={};
    }
  });